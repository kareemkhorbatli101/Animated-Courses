# IELTS 2026 — Volume 1 (B1, band 5.0)

**File:** `IELTS_2026_B1_Volume_1.docx` — 468 pages, 436 figures, 4.3 MB
**Units:** 1–10 (the first ten of the sixty-unit main sequence)
**Level:** CEFR B1 · cover band 5.0 · reading speed 100–120 words a minute

This is the entry volume of the eight-book series, and the first one that
counts *downwards*: Volumes 2 to 6 were built before it, so every band,
every density window and every head word in it had to be set against
books that already existed. Nothing here repeats a head word taught
later, and the register sits a measured step below Volume 2.

---

## 1. What is in the book

| | |
|---|---|
| Units | 10, five cycles each |
| Cycles | 50, each one a full pass through reading, listening, speaking, writing, grammar, vocabulary, expressions and transitions |
| Unit reading | 15,139 words across 50 passages |
| Listening scripts | 12,253 words, every unit covering Parts 1–4 |
| Unit questions | 692, numbered continuously through each unit |
| Timed papers | 2 — a full Reading paper (3 passages, 1,443 words, 40 questions) and a full Listening paper (4 parts, 40 questions) |
| Writing models | 9,165 words of worked models, General Training and Academic |
| Head words | 400, none shared with any other volume |
| Figures | 27 in the units (12 bar charts, 6 line graphs, 3 site-map pairs, 3 process flows, 3 device schematics), 436 rendered plates in all |

### The ten units

| Unit | Theme | The five cycles |
|---|---|---|
| 1 | Education and Learning | Enrolling at a college · How people study · Learning outside school · Why some schools do better · What the evidence leaves out |
| 2 | Work and Careers | Applying for a job · The first weeks in a job · Working hours · What automation does to work · Why the fear keeps returning |
| 3 | Health and Medicine | Registering with a surgery · Sleep and health · What a hospital measures · Why people live longer than they did · What the figures hide |
| 4 | Environment and Conservation | Recycling where you live · Rivers and what goes into them · Measuring a river · Why protecting one species is hard · What a reserve cannot reach |
| 5 | Technology and Computing | Getting online · Passwords and privacy · Screens and attention · How a search engine ranks a page · What ranking cannot settle |
| 6 | Travel and Tourism | Arranging a trip · Visitors and residents · When visitors arrive · What tourism does to a place · Whether limits would work |
| 7 | Cities and Housing | Renting a flat · Who lives where · How a neighbourhood changed · Why housing costs what it does · What building more would not fix |
| 8 | Food and Agriculture | Buying food · Cooking and eating together · From farm to plate · Feeding more people from the same land · What yield leaves out |
| 9 | Media and Communication | Joining a library · Talking at a distance · How a message travels · What a language carries · Whether a language shapes thought |
| 10 | Sport and Fitness | Using the sports centre · Starting and stopping · Who takes part · What training actually does · Whether early specialisation works |

Each unit runs the same shape: cycle 1 pairs two short General Training
texts with a Part 1 listening, cycle 2 is the four-short-texts task,
cycle 3 is a General Training work text with the unit's figure, and
cycles 4 and 5 are Academic passages. The academic end of the book is
where the register window is enforced; the early cycles are deliberately
lighter, because a B1 candidate meets those texts first.

---

## 2. Technique taught, unit by unit

The series rule holds here as everywhere: **skills and technique, not
hacks, and receptive before productive.** Volume 1 introduces the core
loop and nothing else:

1. **Orient, then load the questions, then read one paragraph at a time.**
   Taught in unit 1 and used in all fifty cycles.
2. **Headings before detail.** Unit 2 teaches matching headings and the
   unequal pair; unit 3 teaches matching information.
3. **Out-of-order questions as a memory aid** — unit 4's keyword trap and
   overlap test.
4. **Underline and keep reading.** Taught from unit 1, drilled throughout.
5. **Recovering from a miss in Listening** — unit 5, the skill that keeps
   one lost answer from costing three.
6. **Maps** — unit 7, with two site plans of the same twelve hectares.
7. **Phase boundaries in a process** — unit 8, with a seven-stage,
   three-phase dairy flow and the intruder exercise.
8. **Matching features** — unit 9, on a mobile-network schematic.
9. **A full timed Reading section under the clock** — unit 10.

Writing is built the same way: unit 1 outlines the six tests, unit 3
fills an outline from a passage, unit 5 turns an outline into an essay,
unit 6 runs passage → outline → essay end to end, unit 7 brainstorms
nine ideas, unit 9 judges a published plan, and unit 10 puts the whole
toolkit together. The eleven essay structures and the ten Task 1
principles are introduced at the pace a B1 writer can carry; 1D, 2D and
hybrid Task 1 organisation all appear. The 2-to-5 speaking rule runs
through every speaking block. No templates anywhere.

---

## 3. Register: how the level was set

The level is a measurement, not a claim. Two numbers are gated: the
share of running words from the first 1,000 most frequent English words
(`k1`), and the share beyond the first 2,000 plus the academic list
(`beyond`).

| | k1 | beyond | words | |
|---|---|---|---|---|
| Unit academic passages | 70.0% | 13.5% | 8,152 | in window |
| Timed Reading paper | 69.4% | 12.9% | 1,437 | in window |
| **Both together (gated)** | **69.9%** | **13.4%** | **9,589** | **in window** |

Window: k1 69.0–71.5%, beyond 11.5–14.5%.

Getting there took three passes. The first draft of unit 1 measured
76.1% / 7.1% — far too easy. A denser rewrite overshot to 64.5% / 18.6%.
The landing point came from a measured back-substitution pass: 75
heavy→plain rules, applied in order, with the k1 and beyond figures read
off at each step; 45 rules put the volume in the window. The rules were
applied to the academic cycles only, with answer tokens protected, so no
question lost its key.

The two productive bands do **not** scale down with the cover band: a
model answer has to satisfy the Cambridge rubric at any level, so the
writing models in Volume 1 are held to the same standard as those in
Volume 6.

---

## 4. Gates

All five pass on the shipped file:

| Gate | Result |
|---|---|
| `check.py 1-10` — bands, numbering, Listening Parts 1–4, head-word seams, explanation length | 10 units, 400 head words, 2 timed papers — **all checks pass** |
| `density.py 1` — the register window above | **in window** |
| `book.py 1` — build | 468 pages, 436 images, no errors |
| `omit.py 1` — zero omissions | 4,577 strings checked, **every passage, script turn, model, question and explanation is in the file** |
| `gate6.py 1` — figure text fitting | 3,686 fitted runs: **0 overrun, 0 under 7.5px** |

---

## 5. Three figure defects found by eye, not by a gate

Reading the rendered pages turned up three faults that every gate passed
over. All three were in shared machinery, so all three were latent in
other volumes too; all three are now fixed at source.

1. **`process_flow` — a phase that wraps onto a second row.** The phase
   band was drawn as one rectangle round the whole bounding box, which
   reaches back under the row above and paints over the previous phase's
   label. Unit 8 printed **"On the far"**. Now one band per row, and
   every band is drawn before any label. *Also latent in Volume 2 unit
   18 and Volume 4 units 32, 36 and 38.*
2. **`site_map` — road labels.** They were set 11px clear of the road
   band, which put them under the buildings whenever a road ran close to
   one. Unit 7 clipped "Brackwell Road" in both panels and lost "New
   footpath" entirely. Labels now go on last, on the road itself, each
   on its own paper patch.
3. **`device_schematic` — flow captions.** The caption patch hung above
   its anchor, so a label on a short vertical arrow rode up into the box
   it came from; the offset ignored the patch's own extent, so a label
   could cover the arrow it names; and nothing stopped two labels
   landing on each other. Unit 9 showed all three at once. The patch is
   centred now, pushed clear by its own extent along the normal, and the
   side is chosen by scoring both candidates against the parts, the
   plate edge and the labels already placed.

A fourth fault was caught before the build: units 1 and 2 passed
single-series bar charts as `[(label, value), …]` with no `cats` key,
which crashed the build with `KeyError: 'cats'` *after every content
gate had passed*. Both are rewritten, and the build now renders every
figure in the volume directly before it starts, so that whole class of
error surfaces in seconds rather than six minutes in.

---

## 6. Open items

- ~~**Volumes 2 and 4 should be rebuilt**~~ Done: Volumes 2 to 6 were
  all rebuilt on the fixed renderers, and all five pass zero omissions
  and the figure fitting gate.
- ~~**Volume 3's label.**~~ Fixed on 16 November: `VOLS[3]` and the
  `level=` line of units 21 to 30 now say **B2**, as the series plan
  always had it. Volume 3 was rebuilt and is now
  `IELTS_2026_B2_Volume_3.docx`; no occurrence of "B1+" survives in it.
- ~~**The syntax window**~~ **Closed on 17 November.** `density.py` now gates
  the two syntactic numbers against a laddered window, and `density.py --ladder`
  checks the eight books together. Volume 1 measures **20.2 words a sentence**
  (window 19.4-21.4), longest sentence **37**, nominalisation **3.0%** — all in
  window. The gate failed six of the eight books when it was written, and about
  275 sentences across the series were split or merged to pass it; the worst
  failure was that the B1 book had the longest sentences in the series and the
  C1 book did not. The full account is in `IELTS_Syntax_Ladder_Report.md`,
  including what the gate still does not prove.

---

## The ten-phase fix, as it landed in Volume 1

`IELTS_Fix_Plan.md` set out ten phases after the eight books were first
delivered. All ten have shipped, and this is what they put into this book.

| | |
|---|---|
| Pages, rebuilt | 510 |
| Rendered figures | 445 |
| Questions | 865 |
| Four-option items | 227 |
| Wrong-option lines written | 681 |
| Speaking, as a share of a unit | 13.4-15.4% (floor 12%) |
| Exam-length reading inside the units | 1 stamina read of 685 words |
| Band-6.5 second models | 10 |
| Part 2 long-turn models | 10, one per unit |
| Pronunciation and fluency pages | 10, one per unit |
| "Find the fault" error correction | 10, one per unit |
| Matching sentence endings | 1 set |
| Listening plan or map labelling | 0 set |

The answer-key page of this book now reads **"Every wrong option is
explained, because a letter on its own teaches nothing,"** and `check.py`
fails the build if a line is missing. The book was rebuilt and passes all
nine gates; `regress.py 8` reports no undeclared difference against the
baseline.

**What this does not prove.** The wrong-option lines are gated for
presence and for a 25-character floor, not for truth: `freeze.py` records
the field as a count, so a line rewritten at the same length moves nothing
in the baseline. Nobody has read all of them a second time. The full
account, including the three defects the invariance contract caught and
the five things the plan did not fix, is in
`IELTS_Fix_Plan_Completion_Report.md`.

---

## The balance plan, measured in this book

Phases 10 to 15 counted what the ten-phase fix plan never counted: how often each kind of question appears. `gate10.py` holds the answer against a floor, a ceiling and a rule that every type must be taught as a set of at least three questions in one exercise. Those numbers are a declared design target, not a measurement of a Cambridge paper, and the gate says so in its own docstring. What follows is this book, measured by `census.py`.

| | |
|---|---|
| Questions | 865 |
| Four-option items | 222 |
| Wrong-option lines | 900 |
| Part 2 cue cards | 36 |
| Timed papers | Reading, Reading, Listening, Listening, Writing, Speaking |
| Speaking slots | Part 1 30% · Part 2 35% · Part 3 35% (target 25-40% each) |

### Reading · 473 questions

| task type | questions | share | largest set |
|---|---|---|---|
| multiple choice | 20 | 4.2% | 5 |
| True/False/Not Given | 70 | 14.8% | 5 |
| Yes/No/Not Given | 37 | 7.8% | 5 |
| matching information | 66 | 14.0% | 4 |
| matching headings | 36 | 7.6% | 3 |
| matching features | 64 | 13.5% | 4 |
| matching sentence endings | 5 | 1.1% | 5 |
| sentence completion | 115 | 24.3% | 4 |
| note/table/flow-chart completion | 18 | 3.8% | 5 |
| plan/map/diagram labelling | 6 | 1.3% | 3 |
| short answer | 36 | 7.6% | 4 |

### Listening · 392 questions

| task type | questions | share | largest set |
|---|---|---|---|
| multiple choice | 46 | 11.7% | 5 |
| matching | 12 | 3.1% | 6 |
| plan/map/diagram labelling | 12 | 3.1% | 6 |
| note/table/flow-chart completion | 145 | 37.0% | 10 |
| sentence completion | 102 | 26.0% | 4 |
| short answer | 75 | 19.1% | 5 |

`gate10.py` passes on this book: every type above is taught as a set of three or more, no type is over its ceiling, and no family is under its floor.
