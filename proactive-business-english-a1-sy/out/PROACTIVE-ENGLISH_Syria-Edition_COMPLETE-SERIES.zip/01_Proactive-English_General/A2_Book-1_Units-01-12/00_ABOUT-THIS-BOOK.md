# Proactive English (general) · A2 · Book 1 · Units 1–12

**This is the sixteenth book of the series, and it is the one book here that was not built in
this repository.**

It was written before the repository existed and arrived only as a production handover — the
two bound volumes you see here, plus a handover document and text extractions that were used
to harvest continuity into Book 2. The general A2 tree's own README describes itself as
*"Units 13–24 of Proactive English (A2), continuing the Syria Edition from Book 1."*

**Measured from the files themselves:**

| | Pages | Words | Units |
| --- | ---: | ---: | ---: |
| `01_Students-Book_BOUND.docx` | **368** | 114,869 | 1–12 |
| `02_Answer-Key_COMBINED.docx` | **197** | 67,052 | 1–12 |

⚠ **This folder holds two files where every other book folder holds six plus a `units/`
directory, and that is not an omission in the packaging.** Both tests — the Mid-Book Test and
the End-of-Book Test — are **bound inside** these two volumes rather than supplied as separate
papers, and there are no per-unit files, because the per-unit sources for this book were never
in the repository. What is here is the complete book: twelve units and both tests, in the
Student's Book, with every answer in the Answer Key.

**So the series is complete at 16 books.** Teach it first; Book 2 continues the same cast.
