# English for Banking and Finance · B1 · International

**Author: Mo (Mohamad Khorbatli).**

A single book. **1 Student Book · 10 units · 134 pages.** A single standalone book.

Every page figure here is **measured from the built document**, not estimated.

## What is in this package

```
00_START-HERE.md     this file
01_Student-Books/    the finished book(s), .docx, ready to print or teach from
02_Plans/            the adaptation plan for each book
03_Source/           one zip per book: the unit source text, the build
                     scripts and the QA harness that checked it
```

## The book(s)

| Book | Edition | Level | Units | Pages | Answers |
| --- | --- | --- | ---: | ---: | --- |
| **English for Banking & Finance** | International Edition | B1 | 10 | **134** | NONE |

## ⚠ One thing this package does NOT contain

**This book has no answer key:** *English for Banking & Finance*.

The units carry model answers and self-check boxes where the task has one right answer,
but there is no appendix of answers and no separate key. **A teacher can teach from the
book as it stands; a learner working alone cannot mark their own work.** This is stated
here rather than left to be discovered, and the answer key can be written from the unit
source in `03_Source/` if it is wanted.

## Rebuilding a book

Unzip the book's source from `03_Source/`. The content is plain text with typographic
markers (`@UNIT`, `@EX`, `@GRAMMAR`, `@MODEL` and so on); the build scripts in `build/`
turn it into the .docx, and `qa/` holds the checks that were run against it before the
book was accepted.

⚠ **The QA harness is not a spell-checker.** It checks structure — that every unit has the
elements the design system requires, in the right order and the right number — which is
what keeps the twin editions identical and what makes a page count predictable.
