# Proactive Business English · Syria Edition · A1 → B2

**Author: Mo (Mohamad Khorbatli).**

**8 books · 84 units · 588 teaching cycles · 5,442 pages.** The business English course only —
nothing else from the library is in this package.

Every page figure here is **measured from the built document**, not estimated.

---

## What is in this package

```
00_START-HERE.md        this file
01_FULL-SYLLABUS.md     all 84 units and all 588 objectives, in teaching order
A1_Book-1_Units-01-06/  … one folder per book, eight in all
B2_Book-2_Units-13-24/
90_Plans-and-Handovers/ the plan and handover for each level, plus the Series Bible
91_Source-Pipelines/    the build pipeline for each level
```

**Each book folder holds the same files**, so you need learn the layout only once:

```
01_Students-Book_BOUND.docx          the book in teaching order, with a title page
02_Answer-Key_COMBINED.docx          every unit key and every test key
03_Mid-Book-Test.docx                after the book's sixth unit
04_Mid-Book-Test_Answer-Key.docx
05_End-of-Book-Test.docx             after the book's last unit
06_End-of-Book-Test_Answer-Key.docx
units/                               the same units again, one .docx each, for printing
```

⚠ **The two A1 folders hold four files, not six, and that is correct.** A1 is the only level with
**six-unit books**, so the test at the end of each book *is* the mid-point of the course and there
is no mid-book test. A1 Book 1 closes with the Book 1 Test (60 marks) and Book 2 with the
End-of-Course Test (100 marks).

---

## The eight books

| Level | Book | Units | Student's Book | Answer Key | Closing test |
| --- | ---: | --- | ---: | ---: | --- |
| **A1** | 1 | 1–6 | **165** | **125** | Book 1 Test · 60 marks · 30 Q |
| **A1** | 2 | 7–12 | **193** | **142** | End-of-Course Test · 100 marks · 50 Q |
| **A2** | 1 | 1–12 | **383** | **213** | 100 marks · 30 · 30 · 20 · 20 |
| **A2** | 2 | 13–24 | **451** | **253** | 100 marks · 30 · 30 · 20 · 20 |
| **B1** | 1 | 1–12 | **487** | **298** | 100 marks · 25 · 25 · 25 · 25 |
| **B1** | 2 | 13–24 | **538** | **327** | 100 marks · 25 · 25 · 25 · 25 |
| **B2** | 1 | 1–12 | **555** | **376** | 100 marks · 25 · 25 · 25 · 25 |
| **B2** | 2 | 13–24 | **559** | **377** | 100 marks · 25 · 25 · 25 · 25 |
| | | **84** | **3,331** | **2,111** | |

⚠ **The paper split follows the examination each level is anchored to, and it changes at B1.**
A1 and A2 use the A2 Key weighting (30 · 30 · 20 · 20). B1 and B2 use Business Preliminary and
Business Vantage, which weight the four skills **equally**. ⚠ **B1 goes further: its examination
reports the overall result as the AVERAGE of four skill scores, so both B1 keys tell the teacher
to write the four scores and the average and never the total** — because a learner shown only a
total will optimise the total, which is the habit a four-skill average exists to break.

---

## The shape of every unit

**Seven cycles a unit. Each cycle is one 90-minute lesson in thirteen stages.**

Lesson A, speaking (45 min): Get ready · Listen and read (+ Language box) · Practise · Perform ·
Your turn · Report.
Lesson B, writing (45 min): Read (+ Writer's box) · Write with help · Check together · Share ·
Write freely · Respond · Share · Homework.

**Cycle 7 of every unit is Review & Mediate**, and the mediation is the course's signature: a
disagreement in which **both people are right**, which the learner resolves by naming what each
one is right about. Across 84 units there is almost no cycle in which somebody is simply at fault.

**The Answer Key rule:** *every* task has an answer or a full sample answer — brainstorms,
personalised speaking, reports, peer-review checklists, feedback slips, free writing and homework
included. There is no task in these 5,442 pages a teacher has to improvise.

**Audio scripts are printed at the point of use** in the Student's Book, not in an appendix.

---

## What this package does NOT contain

⚠ **There is no business C1 and no business C2.** The course runs A1 → B2 and stops. The general
*Proactive English* strand goes to C1, so the two strands do not currently reach the same height;
business C1 is the gap if you want parity.

⚠ **There is no International Edition of this course.** Every book here is the Syria Edition —
Damascus, Aleppo, Homs, and a cast that recurs across all four levels. An International edition is
listed as planned in the Series Bible and was never built.

**Not to be confused with** a separate book called *English for Business · International*. Its name
promises this course and it is not it: all ten of its units are set in a group accounts office, and
it has no answer key.

---

## Rebuilding any of it

Each level's pipeline is in `91_Source-Pipelines/`: one script per unit, one per key, the shared
renderer (`lib.js`, frozen and byte-identical across all four levels), the bound-volume builder and
the QA harness.

```
cd pipeline && node qa.js && ./build.sh bound
```

⚠ **`node qa.js` must print `0 fault(s)` before a build is kept**, and it must be run over the
**whole tree** rather than the units you touched — a lexis collision is *between* two units and a
single-unit run cannot see one.

**All four levels build clean.**
