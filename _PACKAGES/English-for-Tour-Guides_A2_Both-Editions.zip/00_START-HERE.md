# English for Tour Guides · A2 · Both Editions

**Author: Mo (Mohamad Khorbatli).**

Two editions of one book. **2 Student Books · 20 units · 502 pages.** Two editions of one book, built as exact structural twins.

Every page figure here is **measured from the built document**, not estimated.

## What is in this package

```
00_START-HERE.md     this file
01_Student-Books/    the finished book(s), .docx, ready to print or teach from
02_Plans/            the adaptation plan for each book
03_Source/           one zip per book: the unit source text, the build
                     scripts and the QA harness that checked it
```

## The book(s)

| Book | Edition | Level | Units | Pages | Answers |
| --- | --- | --- | ---: | ---: | --- |
| **English for Tour Guides** | Syria Edition | A2 | 10 | **251** | Appendix A + B |
| **English for Tour Guides** | International Edition | A2 | 10 | **251** | Appendix A + B |

⚠ **The two editions are structural twins and the page counts prove it.** They are the
same book, unit for unit and exercise for exercise; only the setting changes — the Syria
Edition is set in Damascus, Aleppo and Homs throughout, and the International Edition
moves through ten non-English-speaking countries, one per unit. **A teacher who knows one
edition knows the other**, and a class can be switched between them mid-course without
losing its place.

## Rebuilding a book

Unzip the book's source from `03_Source/`. The content is plain text with typographic
markers (`@UNIT`, `@EX`, `@GRAMMAR`, `@MODEL` and so on); the build scripts in `build/`
turn it into the .docx, and `qa/` holds the checks that were run against it before the
book was accepted.

⚠ **The QA harness is not a spell-checker.** It checks structure — that every unit has the
elements the design system requires, in the right order and the right number — which is
what keeps the twin editions identical and what makes a page count predictable.
