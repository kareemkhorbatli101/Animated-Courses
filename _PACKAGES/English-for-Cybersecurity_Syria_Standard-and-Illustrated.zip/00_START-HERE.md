# English for Cybersecurity · Syria · Standard and Illustrated

**Author: Mo (Mohamad Khorbatli).**

A series. **2 Student Books · 20 units · 393 pages.** Two books on one subject: the A2 text, and an illustrated A2-to-B1 book with its own figure set.

Every page figure here is **measured from the built document**, not estimated.

## What is in this package

```
00_START-HERE.md     this file
01_Student-Books/    the finished book(s), .docx, ready to print or teach from
02_Plans/            the adaptation plan for each book
03_Source/           one zip per book: the unit source text, the build
                     scripts and the QA harness that checked it
```

## The book(s)

| Book | Edition | Level | Units | Pages | Answers |
| --- | --- | --- | ---: | ---: | --- |
| **English for Cybersecurity · Book 1** | Syria Edition | A2 | 10 | **251** | Appendix A + B |
| **English for Cybersecurity Personnel · Illustrated** | Syria Edition | A2-B1 | 10 | **142** | NONE |

## ⚠ One thing this package does NOT contain

**This book has no answer key:** *English for Cybersecurity Personnel · Illustrated*.

The units carry model answers and self-check boxes where the task has one right answer,
but there is no appendix of answers and no separate key. **A teacher can teach from the
book as it stands; a learner working alone cannot mark their own work.** This is stated
here rather than left to be discovered, and the answer key can be written from the unit
source in `03_Source/` if it is wanted.

## Rebuilding a book

Unzip the book's source from `03_Source/`. The content is plain text with typographic
markers (`@UNIT`, `@EX`, `@GRAMMAR`, `@MODEL` and so on); the build scripts in `build/`
turn it into the .docx, and `qa/` holds the checks that were run against it before the
book was accepted.

⚠ **The QA harness is not a spell-checker.** It checks structure — that every unit has the
elements the design system requires, in the right order and the right number — which is
what keeps the twin editions identical and what makes a page count predictable.
