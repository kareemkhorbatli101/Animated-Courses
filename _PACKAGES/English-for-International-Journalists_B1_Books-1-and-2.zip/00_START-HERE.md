# English for International Journalists · B1 · Books 1 and 2

**Author: Mo (Mohamad Khorbatli).**

A series. **2 Student Books · 20 units · 549 pages.** A two-book series: Book 1 then Book 2, same cast and newsroom.

Every page figure here is **measured from the built document**, not estimated.

## What is in this package

```
00_START-HERE.md     this file
01_Student-Books/    the finished book(s), .docx, ready to print or teach from
02_Plans/            the adaptation plan for each book
03_Source/           one zip per book: the unit source text, the build
                     scripts and the QA harness that checked it
```

## The book(s)

| Book | Edition | Level | Units | Pages | Answers |
| --- | --- | --- | ---: | ---: | --- |
| **English for International Journalists · Book 1** | International Edition | B1 | 10 | **226** | inline |
| **English for International Journalists · Book 2** | International Edition | B1 | 10 | **323** | inline |

## Rebuilding a book

Unzip the book's source from `03_Source/`. The content is plain text with typographic
markers (`@UNIT`, `@EX`, `@GRAMMAR`, `@MODEL` and so on); the build scripts in `build/`
turn it into the .docx, and `qa/` holds the checks that were run against it before the
book was accepted.

⚠ **The QA harness is not a spell-checker.** It checks structure — that every unit has the
elements the design system requires, in the right order and the right number — which is
what keeps the twin editions identical and what makes a page count predictable.
