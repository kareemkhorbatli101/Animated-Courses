# Proactive English · Syria Edition · A2 · B1 · B2

Everything delivered so far, in one archive. Author: Mo (Mohamad Khorbatli).

Six books across three CEFR levels. Each book is twelve units of seven 90-minute
cycles, with a Mid-Book Test after its sixth unit and an End-of-Book Test after its
twelfth, and is supplied as separate per-unit files **and** as two bound volumes.

---

## What is in each folder

| folder | what it holds |
| --- | --- |
| `A2_Book1_Units01-12/` | **bound Student's Book and bound Answer Key only** — see the note below |
| `A2_Book2_Units13-24/` | 12 Student's Books · 12 Answer Keys · both tests + keys · both bound volumes |
| `B1_Book1_Units01-12/` | as above |
| `B1_Book2_Units13-24/` | as above |
| `B2_Book1_Units01-12/` | as above |
| `B2_Book2_Units13-24/` | as above |
| `SERIES_BIBLE/` | the rules that govern all six books, version 1.2, with the measured record for every level |
| `PLANS_AND_BLUEPRINTS/` | the production plan for each level |
| `HANDOVERS/` | the continuity file for each level — cast, devices, faults found, open items |
| `PIPELINE_SOURCE/` | the Node + docx-js source every file was built from, one folder per level |

⚠ **A2 Book 1 is the two bound volumes only.** It was written by a different
instance in a separate output directory and only its bound Student's Book
(368 pp) and bound Answer Key (197 pp) were ever transferred into this tree.
Nothing is missing from the teaching material — the bound volumes carry all
twelve units and both tests — but there are no separate per-unit files for it
here, and no `PIPELINE_SOURCE` entry, because its scripts live with that
instance. The other five books are complete in both forms.

---

## The six books

| level | book | units | SB pp per unit | AK pp per unit | bound SB | bound AK |
| --- | --- | --- | --- | --- | --- | --- |
| A2 | 1 | 1–12 | 31 | 17–22 | **368** | **197** |
| A2 | 2 | 13–24 | 31–33 | 18–22 | **394** | **270** |
| B1 | 1 | 1–12 | 35–38 | 22–30 | **461** | **317** |
| B1 | 2 | 13–24 | 38–40 | 29–31 | **489** | **381** |
| B2 | 1 | 1–12 | 46–48 | 29–34 | **584** | **395** |
| B2 | 2 | 13–24 | 45–47 | 29–34 | **577** | **394** |

**2,873 pages of Student's Book and 1,954 pages of Answer Key** — 144 units,
1,008 teaching cycles, twelve tests.

## Course length

Four hours a week over about thirty-one teaching weeks: **126 hours a book**, one
academic year. Six books is six years from A2 to the end of B2.

## The exam each level is anchored to

| level | examination | test paper weighting |
| --- | --- | --- |
| A2 | Cambridge A2 Key | 30 · 30 · 20 · 20 |
| B1 | Cambridge B1 Preliminary | 30 · 30 · 20 · 20 |
| B2 | Cambridge B2 First | 40 · 25 · 25 · 10 |

The weighting is not a house constant: it follows the examination, so that a
student's percentage is comparable with a real result.

## Where to start

1. `SERIES_BIBLE/` — the rules, in five pages.
2. The handover for the level you are picking up, in `HANDOVERS/`.
3. The bound Student's Book for that level, which is the book as a teacher sees it.

## Rebuilding anything

Each `PIPELINE_SOURCE/<level>/` folder is self-contained Node. With `docx` installed:

```
export NODE_PATH=$(npm root -g)
bash build.sh <script-name-without-.js> <Out.docx>    # one artefact
bash build.sh bound                                   # both bound volumes
```

`PE_BOOK=1` or `PE_BOOK=2` selects the book. `lib.js` is frozen and
byte-identical across all three levels; it is not to be edited.
