# Proactive Business English · Syria Edition
## A2, B1 and B2 — all six books, complete

**Author: Mo (Mohamad Khorbatli).** Three levels, six books, **72 units, 504 cycles.**
**4,817 pages.** ⚠ **Every page figure in this document was measured in a rendered PDF of the file
that is in this package**, not estimated and not copied forward from an earlier document.

---

## 1 · What is in this package

```
00_START-HERE.md              ← this file
A2_Book-1_Units-01-12/
A2_Book-2_Units-13-24/
B1_Book-1_Units-01-12/
B1_Book-2_Units-13-24/
B2_Book-1_Units-01-12/
B2_Book-2_Units-13-24/
Teacher-Documentation/
Source-and-Plans/
```

**Each of the six book folders has the same six files and one folder:**

| | |
| --- | --- |
| `01_Students-Book_BOUND.docx` | the whole book in teaching order: twelve units with both tests in place |
| `02_Answer-Key_COMBINED.docx` | the twelve unit keys and both test keys |
| `03_Mid-Book-Test.docx` + `04_…Answer-Key.docx` | sits after Unit 6 / Unit 18 |
| `05_End-of-Book-Test.docx` + `06_…Answer-Key.docx` | sits after Unit 12 / Unit 24 |
| `units/` | the twelve units and twelve keys as separate files, for printing one week at a time |

**If you only open two files per book, open 01 and 02.** Everything else is inside them.

---

## 2 · The six books, measured

| | Student's Book | Answer Key | Mid-Book Test | End-of-Book Test |
| --- | ---: | ---: | ---: | ---: |
| **A2 Book 1** · Units 1–12 | **383** pp | **213** pp | 8 + 6 | 9 + 8 |
| **A2 Book 2** · Units 13–24 | **451** pp | **253** pp | 8 + 7 | 10 + 7 |
| **B1 Book 1** · Units 1–12 | **487** pp | **298** pp | 8 + 7 | 12 + 8 |
| **B1 Book 2** · Units 13–24 | **538** pp | **327** pp | 8 + 7 | 12 + 7 |
| **B2 Book 1** · Units 1–12 | **555** pp | **376** pp | 10 + 7 | 13 + 9 |
| **B2 Book 2** · Units 13–24 | **559** pp | **377** pp | 7 + 8 | 13 + 9 |
| **Total** | **2,973** pp | **1,844** pp | | ⚠ **4,817 pp in all** |

**Lexis declared:** 624 items at A2 (26 a unit) · 720 at B1 (30 a unit) · 768 at B2 (32 a unit)
**plus 192 collocations at B2** — ⚠ **2,112 items and 192 collocations, with no repeat inside any
level and none at B1 against A2 or at B2 against either.** **0 QA faults in all three trees.**

**Marks, and they are not the same at every level, because the examinations are not:**

| Level | Anchored to | Split | Reported as |
| --- | --- | --- | --- |
| **A2** | A2 Key | 30 · 30 · 20 · 20 | the total |
| **B1** | B1 Business Preliminary | **25 · 25 · 25 · 25** | ⚠ **the average of the four papers** |
| **B2** | **B2 Business Vantage** | **25 · 25 · 25 · 25** | ⚠ **the average of the four papers** |

⚠ **At B1 and B2 the keys insist on the average and refuse the total**, because one weak paper
cannot be hidden behind three strong ones in the real examination either. **The number to talk to a
candidate about is the lowest of their four.**

---

## 3 · How a unit works — the same in all 72

**Seven cycles a unit. One cycle = one 90-minute lesson in thirteen stages.**

| Lesson A — Speaking | Lesson B — Writing |
| --- | --- |
| 1 Get ready · 2 Listen and read (+ Language box) | 5 Read (+ Writer's box) |
| 3 Practise · 3R Perform | 6 Write with help · 6P Check together · 6R Share |
| 4 Your turn · 4R Report | 7 Write freely · 7P Respond · 7R Share · Homework |

**Cycle 7 of every unit is Review & Mediate**: it revises the six functions, carries one
**exam-practice task** from the level's examination, and ends with a **mediation** — a disagreement
in which everybody is right about something, resolved in a document rather than in a feeling.

**Word counts rise across the six books:** A2 Book 1 ≥25 / 35–60 · A2 Book 2 ≥35 / 60–100 ·
B1 Book 1 ≥50 / 100–140 · B1 Book 2 ≥60 / 140–180 · **B2, both books, ≥80 / 200–240**, with models
at 45–100 rising to 350–480.

⚠ **The B2 tests deliberately ask for LESS than the B2 units do** — 40–50 and 120–140 words, which
are the examination's own lengths — **and both papers print the course's figures beside them with
the difference named as the examination's and not as a reprieve.**

**Peer review rises too, and it is a fixed progression:** bands 1–2 at A2 Book 1 · band 3 at A2
Book 2 and B1 Book 1 · band 3 + *name the reader you are being* at B1 Book 2 · **band 4 at B2** —
*name the criterion, **copy the line you are marking**, then say what you found* — and in **B2
Book 2** one clause more: ⚠ ***and say what your correction would cost the writer.***

---

## 4 · The syllabus, all 72 units

**One company throughout: Sham Trading, Damascus.** Founded 1998 in Bab Touma, moved to Mezzeh in
2011, second store on Baghdad Street opened 8 June. ⚠ **The same people appear in all six books and
grow older.** **Nour Mansour** is a new administrator at A2 Unit 1; she runs the administration of
an exporter by B1 Unit 24; she inherits the office on 1 July in B2 Unit 20; and at B2 Unit 24 she
opens the letter she sealed to herself two years earlier and finds that one of the two gaps she
named is still open.

### A2 Book 1 — the working day

| | | | |
| ---: | --- | ---: | --- |
| 1 | Meeting People at Work | 7 | Appointments and Arrangements |
| 2 | The Working Day | 8 | Last Week at Work |
| 3 | The Office and the Warehouse | 9 | Duties, Rules and Permission |
| 4 | Stock, Orders and Quantities | 10 | Health and Safety at Work |
| 5 | Prices, Payment and Invoices | 11 | Business Travel |
| 6 | Deliveries and Transport | 12 | Courtesy and Company Customs |

### A2 Book 2 — the company in its trade

| | | | |
| ---: | --- | ---: | --- |
| 13 | Experience and the CV | 19 | Suppliers and Partners |
| 14 | Plans and Forecasts | 20 | Services and Repairs |
| 15 | Problems and Solutions at Work | 21 | Quality and Complaints |
| 16 | Then and Now | 22 | Emails and Requests |
| 17 | Training and Learning at Work | 23 | The Company and the City |
| 18 | Technology at Work | 24 | Looking Forward |

### B1 Book 1 — the written account, and the auditor

| | | | |
| ---: | --- | ---: | --- |
| 1 | The Account and the Person | 7 | Cause, Effect and the Written Explanation |
| 2 | Telling the Story of a Working Day | 8 | Options, Advice and the Second Conditional |
| 3 | What Had Already Happened | 9 | Deduction, Doubt and the Honest Estimate |
| 4 | Experience and Evidence | 10 | Reporting What Was Said |
| 5 | How It Is Done Here | 11 | Defining and Adding |
| 6 | Obligation, Authority and Permission | 12 | Opinions, Agreement and the Decision |

### B1 Book 2 — the export book: a reader who cannot telephone the warehouse

| | | | |
| ---: | --- | ---: | --- |
| 13 | Plans, Intentions and Arrangements | 19 | Complaints, Claims and Resolutions |
| 14 | Forecasts and Probability | 20 | Instructions, Specifications and the Bench Page |
| 15 | What Went Wrong, and the Honest Report | 21 | Negotiating and Compromise |
| 16 | Comparing Suppliers and Evaluating Offers | 22 | Interviews, Appraisals and Self-Presentation |
| 17 | The Way It Used to Be Done | 23 | Trade News and What Is Actually Known |
| 18 | Verb Patterns and the Week in Its Verbs | 24 | Looking Ahead to B2 |

### B2 Book 1 — the contract Nour thinks is a mistake

| | | | |
| ---: | --- | ---: | --- |
| 1 | What Is Already Decided, and What Is Not | 7 | Cause at a Distance |
| 2 | Taking Yourself Out of the Sentence | 8 | Numbers in Prose |
| 3 | The Case Against a Decision Already Half-Taken | 9 | Somebody Else's Draft |
| 4 | Risk, Exposure and the Thing You Cannot Model | 10 | The Meeting You Did Not Call |
| 5 | Policy, Not Procedure | 11 | The Thing You Have To Say |
| 6 | Three Readers, One Fact | 12 | The Decision You Take |

### B2 Book 2 — everything Nour did not decide

| | | | |
| ---: | --- | ---: | --- |
| 13 | The Contract You Have to Live Inside | 19 | Arbitration, and the Room Where Nobody Is on Your Side |
| 14 | Acceptance, Rejection and the Measurable Standard | 20 | Succession, and the Week After You Have Gone |
| 15 | Writing to Somebody Who Has Already Said No | 21 | Proposals, and the Option You Argue Against |
| 16 | The Argument You Do Not Hold | 22 | Reviews, and the Document That Must Not Agree |
| 17 | Summarising at Length | 23 | Trade and Policy, and the Rule Nobody Wrote for You |
| 18 | The Long Read, and the Document That Outlives You | 24 | Opening the Letters |

---

## 5 · What the three levels are each for

⚠ **The whole course is one argument, and it is about the reader.**

**A2 teaches a learner to write the thing down.** By the end of A2 Book 2 they can write a CV, a
forecast, a problem report, a complaint, an email that asks for one thing, and a description of
their own company.

**B1 teaches them to write it for somebody who cannot ask a question.** Book 1 builds the ten
documents a coordinator writes — a handover note, a procedure page, an authority matrix, an
incident report, an options paper, an inspection note, minutes, a correction to terms, a position
paper — against a reader who is paid to find the gap. Book 2 is the export book: every document has
to work for a buyer in Beirut who cannot telephone the warehouse, and for a night-shift worker who
is alone at two in the morning and cannot ask.

**B2 teaches them to write it for a reader who CAN ask a question and CAN refuse, and does not have
to say why.** Book 1 is the apparatus for arguing upward — the brief, the impersonal account, the
case against a decision half-taken, the risk you cannot model, the three readers and one fact, the
root cause months away, the figure with its base, somebody else's draft, the meeting you did not
call, the thing you have to say, the decision you take. Book 2 is everything the learner did not
decide and is answerable for anyway: a contract signed in a form she argued against, an arbitration,
an office handed to her, a Ministry notice written for another trade, and a reference about somebody
else.

### ⚠ The four things that run through B2, and what its End-of-Book Test marks

1. **A document is written for what a reader will DO with it, and the reader may refuse.**
2. **A claim carries its own warrant, and names what it does not cover.**
3. **A figure, a date and a name are checkable; a disposition is not, and cannot be acted on by
   Monday morning.**
4. **What outlives you is one document, and it will be read by somebody who cannot ask.**

---

## 6 · Teacher documentation

`Teacher-Documentation/`

| File | What it is |
| --- | --- |
| `HANDOVER_A2_both-books.md` | the A2 level: every measured figure, the harness, the faults it caught |
| `HANDOVER_B1_Book-1.md` | B1 Book 1, and the ten documents it builds |
| `HANDOVER_B1_Book-2.md` | B1 Book 2, the export spine, and what to do next at B2 |
| `HANDOVER_B2_Book-1.md` | B2 Book 1, the upward argument, and the four harness faults it found |
| `HANDOVER_B2_Book-2.md` | B2 Book 2, the level closed, the test-projection record, and the one instruction that happens after the course |
| `SERIES-BIBLE_v1.8.docx` | eleven pages: every measured band, test figure and finding across the whole series, including the general A2–C1 course |

⚠ **The Series Bible is the file to read if you are going to build anything else.** It carries the
findings that cost something to learn — among them that **words per page is not a constant** (it
varies by a factor of 2.6 across this strand's test documents), that **no test page projection in
this series has ever beaten plus or minus one page except by luck**, and that the right response is
to **build and measure earlier rather than to project better.**

---

## 7 · Rebuilding any of it

`Source-and-Plans/` holds `pipeline_A2.zip`, `pipeline_B1.zip`, `pipeline_B2.zip` and the three
plans of record. Each pipeline is one JavaScript file per unit, one per key, the four test scripts,
a frozen renderer (`lib.js`), the bound-volume builder, and the QA harness.

```
unzip pipeline_B2.zip && cd pipeline
node qa.js                            # whole level: 768 lexis items, 192 collocations, 0 faults
PE_LEVEL=B2 ./build.sh bound          # Book 1 bound volumes
PE_LEVEL=B2 PE_BOOK=2 ./build.sh bound   # Book 2 bound volumes
```

⚠ **Three standing rules, each of which cost something to learn:**

- **Load a script before you build it** — `node -e "require('./unit20.js')"`. The loader names the
  bad line; the renderer does not.
- **Run `qa.js` over the whole tree, not over the units you touched.** A lexis or collocation
  collision is between two units and a single-unit run cannot see one.
- ⚠ **`qa.js` must print `0 fault(s)` before a build is kept.**

---

## 8 · One thing to do with the last unit, at every level

B1 Unit 24.7 reports a count taken at this company: **eleven people took the A2 course, three still
write anything in English two years later, and they are not the three with the best marks.** What
the three have in common is that **somebody is waiting for a document from each of them every week
and would notice if it did not come.**

⚠ **So the last session of each level is not a test.** It is **one document, one reader, one date
inside the following fortnight**, written on a list the teacher keeps — **and the teacher asks in
October**, by reading the candidate's own line back to them and asking for the date it was written
and who received it.

⚠ **At B2 the course makes that instruction about itself.** Unit 24 opens the letter the learner
sealed two years earlier at B1, counts the undertakings they made against a count made from the
record, and ends by sealing a new letter whose reader has **agreed in their own handwriting** to
ask for it on a stated day. **The B2 End-of-Book Test key tells the teacher to expect about a third
to deliver, and records that figure so the next teacher has something to compare with.**

**It is the only instruction in 4,817 pages for something that happens after the course, and it is
the one that decides whether any of the other pages survive.**

---

_Proactive Business English · Syria Edition · A2, B1 and B2 · built on branch
`claude/intl-journalists-book-adapt-9no27e`._
