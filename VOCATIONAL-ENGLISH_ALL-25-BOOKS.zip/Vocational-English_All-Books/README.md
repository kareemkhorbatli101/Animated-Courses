# Vocational and Professional English — all 25 books

Every book in this archive is a complete Student's Book. Author: Mohamad Khorbatli.
**5,888 pages across 25 titles.**

Two families, in two folders.

---

## 1 · `01_Paired_A2_Syria_and_International/` — eight courses, two editions each

A2, ten units each. Every course exists as a **Syria edition** and an
**International edition**: the same syllabus, the same unit structure, and the
local edition's places, names, currency and workplace detail replaced throughout
for a reader anywhere. Each folder holds both Student's Books and the production
plan for each edition.

| course | Syria | International |
| --- | --- | --- |
| Architects | 251 pp | 251 pp |
| Business Managers | 252 pp | 252 pp |
| Content Creators | 252 pp | 252 pp |
| Logistics | 252 pp | 252 pp |
| Office Managers | 252 pp | 252 pp |
| Quality Assurance | 252 pp | 252 pp |
| Tour Guides | 251 pp | 251 pp |
| Tourism Police | 251 pp | 251 pp |

**Sixteen books, 4,026 pages.**

---

## 2 · `02_International_Single_Titles/` — nine titles

International edition only. Levels differ by title and are printed on each
title page.

| folder | title | level | pp |
| --- | --- | --- | --- |
| `Accountants/` | English for Accountants | B1 | 247 |
| `Banking/` | English for Banking | B1 | 134 |
| `Business/` | English for Business | B1 | 190 |
| `ForeignMinistry/` | English for Foreign Ministry Staff Members | B1 | 133 |
| `ForeignMinistry_B1-1/` | English for Foreign Ministry Staff Members (B1.1) | B1.1 | 200 |
| `Journalists_Book1/` | English for Journalists | A2 → lower B1 | 226 |
| `Journalists_Book2/` | English for Journalists · Book 2 · Across Borders | lower → medium B1 | 323 |
| `MediaAndCommunications/` | English for Media and Communications (EMC2) | B1 | 152 |
| `NGOs/` | English for NGOs and International Organizations | A2 | 257 |

**Nine books, 1,862 pages.**

The two Journalists books are a sequence: Book 1 follows one story from the first
bulletin to the front page; Book 2 takes four newsrooms through one story
together. They are the only two titles here that run on from each other.

---

## 3 · `SOURCE/` — what each book was built from

One folder per book, holding:

- `content/` — the written text of every unit, as plain text, one file per unit
- `qa/` — the check scripts each book was held to
- `build/` — the build scripts

⚠ **The generated figures are not in `SOURCE/`.** They are already embedded in
every Student's Book `.docx`, and shipping them twice would have doubled the size
of this archive. To regenerate them, run the book's own build scripts.

---

## A note on what is and is not here

- **Student's Books only.** These titles were commissioned as single volumes;
  where a title has appendices or an answer section, it is inside its own
  Student's Book rather than in a separate file.
- **Some titles also carry a `.md`** beside the `.docx` — the same book as plain
  Markdown, useful for searching or re-typesetting.
- The **Proactive English** series (A2, B1 and B2, two books each, with separate
  Answer Keys and tests) is a different project and ships in its own archive.
